#
# Regular cron jobs for the grindsetcalculator package
#
0 4	* * *	root	[ -x /usr/bin/grindsetcalculator_maintenance ] && /usr/bin/grindsetcalculator_maintenance
